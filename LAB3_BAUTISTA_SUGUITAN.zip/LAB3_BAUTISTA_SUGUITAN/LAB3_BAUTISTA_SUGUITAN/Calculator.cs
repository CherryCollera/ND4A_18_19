﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB3_BAUTISTA_SUGUITAN
{
    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 =double.Parse(txtDisplay.Text);

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = true;
            DeclareVar.mulButtonClicked = false;
            DeclareVar.divButtonClicked = false;
            txtDisplay.Clear();


        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = double.Parse(txtDisplay.Text);

            DeclareVar.minusButtonClicked = true;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.mulButtonClicked = false;
            DeclareVar.divButtonClicked = false;
            txtDisplay.Clear();
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = double.Parse(txtDisplay.Text);

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.mulButtonClicked = true;
            DeclareVar.divButtonClicked = false;
            txtDisplay.Clear();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            DeclareVar.total1 = double.Parse(txtDisplay.Text);

            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.mulButtonClicked = false;
            DeclareVar.divButtonClicked = true;
            txtDisplay.Clear();
        }

        private void btnEq_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text != "")
            {
                DeclareVar.total2 = Convert.ToDouble(txtDisplay.Text);
                if (DeclareVar.minusButtonClicked == true)
                {
                    if (DeclareVar.total1 > DeclareVar.total2)
                    {
                        txtDisplay.Text = Convert.ToString(DeclareVar.total1 - DeclareVar.total2);
                    }
                    else if (DeclareVar.total2 > DeclareVar.total1)
                    {
                        txtDisplay.Text = Convert.ToString(DeclareVar.total2 - DeclareVar.total1);
                    }
                    else
                    {

                    }

                    DeclareVar.minusButtonClicked = false;
                }
                if (DeclareVar.plusButtonClicked == true)
                {
                   
                        txtDisplay.Text = Convert.ToString(DeclareVar.total1 + DeclareVar.total2);
                    

                    DeclareVar.plusButtonClicked = false;
                }
                if (DeclareVar.mulButtonClicked == true)
                {
                   
                        txtDisplay.Text = Convert.ToString(DeclareVar.total1 * DeclareVar.total2);
                 

                    DeclareVar.mulButtonClicked = false;
                }
                if (DeclareVar.divButtonClicked == true)
                {
                  
                        txtDisplay.Text = Convert.ToString(DeclareVar.total1 / DeclareVar.total2);
                   

                    DeclareVar.divButtonClicked = false;
                }

            }

               
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDisplay.Clear();
            DeclareVar.minusButtonClicked = false;
            DeclareVar.plusButtonClicked = false;
            DeclareVar.mulButtonClicked = false;
            DeclareVar.divButtonClicked = false;
            DeclareVar.total1 = 0;
            DeclareVar.total2 = 0;

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "1";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "1";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

             
            }
            else
            {
                txtDisplay.Text += "1";
            }


        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "2";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "2";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

             
            }
            else
            {
                txtDisplay.Text += "2";
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "3";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "3";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

           
            }
            else
            {
                txtDisplay.Text += "3";
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "4";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "4";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

           
            }
            else
            {
                txtDisplay.Text += "4";
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "5";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "5";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

              
            }
            else
            {
                txtDisplay.Text += "5";
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "6";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "6";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

            }
            else
            {
                txtDisplay.Text += "6";
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "7";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "7";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {
                
            }
            else
            {
                txtDisplay.Text += "7";
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "8";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "8";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

               
            }
            else
            {
                txtDisplay.Text += "8";
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "9";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "9";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

             
            }
            else
            {
                txtDisplay.Text += "9";
            }
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += "0";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += "0";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {

              
            }
            else
            {
                txtDisplay.Text += "0";
            }
        }

        private void btnDot_Click(object sender, EventArgs e)
        {
            if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text == "")
            {

                txtDisplay.Text += ".";

            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true && txtDisplay.Text != "")
            {
                txtDisplay.Text += ".";
            }
            else if (DeclareVar.divButtonClicked == true || DeclareVar.mulButtonClicked == true || DeclareVar.minusButtonClicked == true || DeclareVar.plusButtonClicked == true)
            {
                
            }
            else
            {
                txtDisplay.Text += ".";
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            this.Hide();
            f.ShowDialog();
            //Environment.Exit(0);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Calculator_Load(object sender, EventArgs e)
        {

        }
    }
}
