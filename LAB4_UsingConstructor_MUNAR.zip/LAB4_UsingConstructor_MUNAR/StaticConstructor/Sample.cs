﻿
namespace StaticConstructor
{
    class Sample
    {
        public string firstname, lastname;

        static Sample()
        {
            System.Console.WriteLine("Static constructor");
        }
        public Sample()
    {
            firstname = "Naneth";
            lastname = "Munar";
    }
    }
}
