﻿

namespace ParametizedConstructors
{
    class Sample
    {
        public string firstname, lastname;
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
    }
}
