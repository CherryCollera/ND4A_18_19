﻿

namespace ConstructorOverloading
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Christian";
            lastname = "Munar";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
    }
}
