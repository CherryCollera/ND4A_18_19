﻿

namespace LAB4_UsingConstructor_MUNAR
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
    
         {
            firstname = "Rhomar";
            lastname  = "Munar";
    
         }
        
    }
}
