﻿using System;


namespace ParametizedMunar
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample a = new Sample("Rhomar", "Munar");
            Console.WriteLine(a.firstname);
            Console.WriteLine(a.lastname);
            Console.ReadLine();
        }
    }
}
