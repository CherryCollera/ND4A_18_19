﻿using System;

namespace UsingConstructors_DominguezYandoc
{
    class Program
    {
        static void Main(string[] args)
        {
            UCons s = new UCons();
            Console.WriteLine(s.fname);
            Console.WriteLine(s.lname);
            Console.ReadLine();
        }
    }
}
