﻿

namespace UsingConstructors_DominguezYandoc
{
    class UCons
    {
        public string fname, lname;
        public UCons()
        {
            fname = "Jhella Jesusa";
            lname = "Dominguez Yandoc";
        }
        
    }
}
