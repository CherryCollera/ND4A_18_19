﻿using System;

namespace StaticConstructor_DominguezYandoc
{
    class Program
    {
        static void Main(string[] args)
        {

            SCons s = new SCons();
            SCons s1 = new SCons();
            Console.WriteLine(s1.fname + ""  + s1.lname);
            Console.ReadLine();

        }
    }
}
