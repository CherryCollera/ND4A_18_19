﻿
namespace StaticConstructor_DominguezYandoc
{
    class SCons
    {
        public string fname, lname;

        static SCons()
        {
           System.Console.Write("Static constructor");
        }
        public SCons()
        {
            fname = "\nJhella Jesusa";
            lname = "\tDominguez Yandoc";
        }
            
    }
}
