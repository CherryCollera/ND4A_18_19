﻿
namespace PrivateConstructor_DominguezYandoc
{
    class PCons
    {
        public string fname, lname;
        public PCons(string x, string y)
        {
            fname = x;
            lname = y;
        }
        private PCons()
        {
            System.Console.WriteLine("Private Constructor with no parameters");
        }

    }
}
