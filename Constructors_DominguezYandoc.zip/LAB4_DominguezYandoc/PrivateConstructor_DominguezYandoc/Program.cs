﻿using System;

namespace PrivateConstructor_DominguezYandoc
{
    class Program
    {
        static void Main(string[] args)
        {
            PCons s = new PCons("Jhella Jesusa", "Dominguez Yandoc");
            Console.WriteLine(s.fname + " " + s.lname);
            Console.ReadLine();
        }
    }
}
