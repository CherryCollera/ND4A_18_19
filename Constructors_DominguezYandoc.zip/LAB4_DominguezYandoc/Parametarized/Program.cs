﻿using System;
namespace Parameterized
{
    class Program
    {
       private static void Main(string[] args)
        {
            Param s = new Param("Jhella Jesusa", "Dominguez Yandoc");

            Console.WriteLine(s.fname); 
            Console.WriteLine(s.lname);
            Console.ReadLine();
       }
    }
}
