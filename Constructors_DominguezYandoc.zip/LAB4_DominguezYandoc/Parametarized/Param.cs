﻿
namespace Parameterized
{
    class Param
    {
        public string fname, lname;
        public Param(string x, string y)
        {
            fname = x;
            lname = y;
        }
    }
}
