﻿using System;

namespace CopyConstructor_DominguezYandoc
{
    class Program
    {
        static void Main(string[] args)
        {
            CCons s = new CCons("Jhella Jesusa", "Dominguez Yandoc");
            CCons s1 = new CCons(s);
            Console.WriteLine(s);
            Console.WriteLine("\n"+s1.fname + "\n\n" + s1.lname);
            Console.ReadLine();

        }
    }
}
