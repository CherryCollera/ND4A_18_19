﻿
namespace CopyConstructor_DominguezYandoc
{
    class CCons
    {
        public string fname, lname;
        public CCons(string x, string y)
        {
            fname = x;
            lname = y;
        }
        public CCons(CCons s)
        {
            fname = s.fname;
            lname = s.lname;
        }
    }
}
