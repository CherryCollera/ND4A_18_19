﻿namespace ConstructorOverloading_DominguezYandoc
{
    class ConsOver
    {
        public string fname, lname;
        public ConsOver()
        {
            fname = "Jhella Jesusa";
            lname = "\tDominguez Yandoc";

        }
        public ConsOver(string x, string y)
        {
            fname = x;
            lname = y;
        }
            
    }
}
