﻿using System;


namespace ConstructorOverloading_DominguezYandoc
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                ConsOver s = new ConsOver();
                ConsOver s1 = new ConsOver("Jhella Jesusa", "\tDominguez Yandoc");
                Console.WriteLine(s.fname + "" + s.lname);
                Console.WriteLine(s1.fname + "" + s1.lname);
                Console.ReadLine();
            }
        }
    }
}
