﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LAB4_Bilog_Rubiano
{
    class Program
    {
        private static void Main(string[] args)
        {
            D d = new D();
            Console.WriteLine(d.firstname);
            Console.WriteLine(d.lastname);
            Console.ReadLine();
        }
    }
}
