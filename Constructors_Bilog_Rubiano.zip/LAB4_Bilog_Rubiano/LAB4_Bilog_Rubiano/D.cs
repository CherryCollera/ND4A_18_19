﻿
namespace LAB4_Bilog_Rubiano
{
    class D
    {
        public string firstname, lastname;
        public D()
        {
            firstname = "Meijie , Juvyrose";
            lastname = "Bilog , Rubiano";
        }
    }
}
