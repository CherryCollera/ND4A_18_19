﻿

namespace Copy.cs
{
    class C
    {
        public string firstname, lastname;
        public C(string a, string b)
        {
            firstname = a;
            lastname = b;
        }
        public C(C c)
        {
            firstname = c.firstname;
            lastname = c.lastname;
        }
    }
}
