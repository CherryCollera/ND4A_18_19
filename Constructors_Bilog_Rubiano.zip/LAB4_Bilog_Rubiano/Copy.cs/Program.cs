﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Copy.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            C c = new C("Meijie , Juvyrose", "Bilog , Rubiano ");
            C c1 = new C(c);
            Console.WriteLine(c);
            Console.WriteLine("\n"+c1.firstname + "\n\n" + c1.lastname);
            Console.ReadLine();
        }
    }
}
