﻿
namespace Parameterized
{
    class P
    {
        public string firstname, lastname;
        private string p;
        public P(string a, string b)
        {
            firstname = a;
            lastname = b;
        
        }
    }
}
