﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parameterized
{
    class Program
    {
       public static void Main(string[] args)
        {
            P p = new P("Meijie , Juvyrose", "Bilog , Rubiano");

            Console.WriteLine(p.firstname);
            Console.WriteLine(p.lastname);
            Console.ReadLine();
        }
    }
}
