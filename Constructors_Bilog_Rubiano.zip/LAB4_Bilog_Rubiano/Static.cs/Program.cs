﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Static.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            S s = new S();
            S s1 = new S();
            Console.WriteLine(s1.firstname + " , " + s1.lastname);
            Console.ReadLine();

        }
    }
}
