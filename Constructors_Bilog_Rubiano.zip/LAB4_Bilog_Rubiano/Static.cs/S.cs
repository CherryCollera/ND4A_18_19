﻿
namespace Static.cs
{
    class S
    {
    
        public string firstname, lastname;

        static S()
        {

            System.Console.WriteLine("Static constructor");
        
        }
        public S()   
{
        
            firstname = "Meijie  Juvyrose";
            lastname = "Bilog  Rubiano";
    }

    }

 }