﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CO.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            ConO s = new ConO();
            ConO s1 = new ConO("Meijie Juvyrose" , "Bilog Rubiano");
            Console.WriteLine(s.firstname + " " + s.lastname);
            Console.WriteLine(s1.firstname + " " + s1.lastname);
            Console.ReadLine();

        }
    }
}
