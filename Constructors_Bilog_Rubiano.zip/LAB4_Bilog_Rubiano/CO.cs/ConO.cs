﻿
namespace CO.cs
{
    class ConO
    {
        public string firstname, lastname;
        public ConO ()
        {
        firstname = "Meijie Juvyrose";
        lastname = "Bilog Rubiano";
    }
    public ConO(string Meijie, string Juvyrose)
{
    firstname = "Meijie";
    lastname = "Juvyrose";
}
    }
}
