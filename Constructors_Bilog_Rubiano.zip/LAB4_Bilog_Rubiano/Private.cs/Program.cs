﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Private.cs
{
    class Program
    {
        static void Main(string[] args)
        {
            Pri p = new Pri("Meijie Juvyrose", "Bilog Rubiano");
            Console.WriteLine(p.firstname + " " + p.lastname);
            Console.ReadLine();
        }
    }
}
