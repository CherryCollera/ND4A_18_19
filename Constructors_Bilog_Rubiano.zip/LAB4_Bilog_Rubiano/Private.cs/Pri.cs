﻿
namespace Private.cs
{
    class Pri
    {
        public string firstname, lastname;
        public Pri(string Meijie, string Juvyrose)
    {
            firstname = Meijie;
            lastname = Juvyrose;
}
        private Pri()
        {
            System.Console.WriteLine("Meijie Juvyrose Bilog Rubiano");
        }
    }

}
