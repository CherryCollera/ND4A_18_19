﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsingConstructors_Api
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Jolina";
            lastname = "Api";
        }
    }
}
