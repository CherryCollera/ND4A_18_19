﻿
namespace PrivateConstructor_MORALES_CRUZMI
{
    class Sample
    {
        public string firstname, lastname;
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
        private Sample()
        {
            System.Console.WriteLine("Private constructor with no parameters");
        }
    }
}
