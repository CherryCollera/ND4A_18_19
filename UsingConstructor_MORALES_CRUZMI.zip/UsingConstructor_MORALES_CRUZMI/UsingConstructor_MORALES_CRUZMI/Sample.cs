﻿

namespace UsingConstructor_MORALES_CRUZMI
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Jerome";
            lastname = "Morales";
        }
    }
}
