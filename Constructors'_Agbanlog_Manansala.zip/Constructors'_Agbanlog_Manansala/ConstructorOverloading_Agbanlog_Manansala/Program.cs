﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication6
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample();
            Sample s1 = new Sample("Liezel", "Manansala");
            Console.WriteLine(s.firstname + " " + s.lastname);
            Console.WriteLine(s1.firstname + " " + s1.lastname);
            Console.ReadLine();

        }
    }
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Liezel";
            lastname = "Manansala";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
    }
}
