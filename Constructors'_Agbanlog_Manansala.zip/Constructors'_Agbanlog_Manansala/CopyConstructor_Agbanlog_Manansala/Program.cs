﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor_Agbanlog_Manansala
{
    class Program
    {
        static void Main(string[] args)
        {
            Sample s = new Sample("Rhina", "Agbanlog");
            Sample s1 = new Sample(s);
            Console.WriteLine(s);
            Console.WriteLine("\n" + s1.firstname + "\n\n" + s1.lastname);
            Console.ReadLine();

        }
    }
    class Sample

    {
        public string firstname, lastname;
        public Sample(string x, string y)
        {
                 firstname = x;
                lastname = y;
        }
        public Sample(Sample s)
        {
            firstname = s.firstname;
            lastname = s.lastname;
        }
    }
}
