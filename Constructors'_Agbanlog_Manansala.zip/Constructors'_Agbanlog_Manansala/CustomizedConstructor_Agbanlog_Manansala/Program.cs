﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorOverloading_Agbanlog_Manansala
{
    class Program
    {
        private static void Main(string[] args)
        {
            Sample s = new Sample();
            Console.WriteLine(s.firstname1);
            Console.WriteLine(s.lastname1);
            Console.WriteLine(s.idnum_1);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(s.firstname2);
            Console.WriteLine(s.lastname2);
            Console.WriteLine(s.idnum_2);
            Console.ReadLine();
        }

    }
    class Sample
    {
        public string firstname1, firstname2, lastname1, lastname2, idnum_1, idnum_2;
        public Sample()
        {
            firstname1 = "Rhina";
            lastname1 = "Agbanlog";
            idnum_1 = "15-02720";

            firstname2 = "Liezel";
            lastname2 = "Manansala";
            idnum_2 = "15-02320";

        }

    }
}
