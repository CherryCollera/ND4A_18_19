﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB3_BARTOLO
{
    class DeclareVar
    {
        public static double total1 = 0;
        public static double total2 = 0;
        public static bool minusButtonClicked = false;
        public static bool plusButtonClicked = false;
        public static bool mulButtonClicked = false;
        public static bool divButtonClicked = false;
    }
}
