﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LAB3_ALKONGA_BISCOCHO_ND4A
{
    class DeclareVar
    {
        public static double total1 = 0;
        public static double total2 = 0;
        public static bool minusButtonClicked = false;
        public static bool plusButtonClicked = false;
        public static bool mulButtonClicked = false;
        public static bool divButtonClicked = false;
       
    }
}
