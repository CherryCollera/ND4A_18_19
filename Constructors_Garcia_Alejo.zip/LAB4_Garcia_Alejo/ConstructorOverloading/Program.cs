﻿using System;
namespace ConstructorOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                CO a = new CO();
                CO a1 = new CO("Ezra , Krisanta", "\tGarcia , Alejo");
                Console.WriteLine(a.firstname + "" + a.lastname);
                Console.WriteLine(a1.firstname + "" + a1.lastname);
                Console.ReadKey();

            }
        }
    }
}
