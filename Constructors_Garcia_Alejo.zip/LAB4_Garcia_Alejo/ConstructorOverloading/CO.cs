﻿

namespace ConstructorOverloading
{
    class CO
    {
        public string firstname, lastname;
        public CO()
        {
            firstname = "Ezra, Krisanta";
            lastname = "\tGarcia, Alejo";
        }
        public CO(string j, string s)
        {
            firstname = j;
            lastname = s;
        }

    }
}
