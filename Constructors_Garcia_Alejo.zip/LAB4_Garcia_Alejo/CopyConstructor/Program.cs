﻿using System;

namespace CopyConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            CC a = new CC("Ezra , Krisanta", "Garcia , Alejo");
            CC a1 = new CC(a);
            Console.WriteLine(a);
            Console.WriteLine("\n" +a1.firstname + "\n\n" + a1.lastname);
            Console.ReadLine();



        }
    }
}
