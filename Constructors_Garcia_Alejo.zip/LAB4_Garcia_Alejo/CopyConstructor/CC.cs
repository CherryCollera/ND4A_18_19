﻿namespace CopyConstructor
{
    class CC
    {
        public string firstname, lastname;
        public CC(string j, string s)
        {
            firstname = j;
            lastname = s;
        }
        public CC(CC a)
        {
            firstname = a.firstname;
            lastname = a.lastname;

        }

    }
}
