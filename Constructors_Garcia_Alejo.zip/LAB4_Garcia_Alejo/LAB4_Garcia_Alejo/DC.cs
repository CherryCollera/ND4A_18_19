﻿

namespace LAB4_Garcia_Alejo
{
    class DC
    {
        public string firstname, lastname;
        public DC()
        {
            firstname = "Ezra , Krisanta";
            lastname = "Garcia , Alejo";
        }
    }
}
