﻿using System;


namespace LAB4_Garcia_Alejo
{
    class Program
    {
       private static void Main(string[] args)
        {
            DC a = new DC();
            Console.WriteLine(a.firstname);
            Console.WriteLine(a.lastname);
            Console.ReadLine();

         
        }
    }
}
