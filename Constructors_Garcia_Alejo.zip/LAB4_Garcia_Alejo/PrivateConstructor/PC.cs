﻿
namespace PrivateConstructor
{
    class PC
    {
        public string firstname, lastname;
        public PC(string j, string s)
        {
            firstname = j;
            lastname = s;
        }
    }
}
