﻿using System;

namespace PrivateConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            PC a = new PC("Ezra , Krisanta", "Garcia , Alejo");
            Console.WriteLine(a.firstname + " "+ a.lastname);
            Console.ReadLine();


        }
    }
}
