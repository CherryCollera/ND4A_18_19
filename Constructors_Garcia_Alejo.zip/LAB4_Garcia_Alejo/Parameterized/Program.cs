﻿using System;

using System;
namespace Parameterized
{
    class Program
    {
        private static void Main(string[] args)
        {
            PM a = new PM("Ezra, Krisanta", "Garcia , Alejo");

            Console.WriteLine(a.firstname);
            Console.WriteLine(a.lastname);
            Console.ReadLine();


        }
    }
}
