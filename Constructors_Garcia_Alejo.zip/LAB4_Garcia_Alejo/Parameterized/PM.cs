﻿

namespace Parameterized
{
    class PM
    {
        public string firstname, lastname;
        public PM(string j, string s)

        {
            firstname = j;
            lastname = s;
        }
        
    }
}
