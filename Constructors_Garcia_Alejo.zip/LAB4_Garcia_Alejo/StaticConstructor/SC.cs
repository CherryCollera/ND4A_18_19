﻿
namespace StaticConstructor
{
    class SC
    {
        public string firstname, lastname;

        static SC()
        {
            System.Console.WriteLine("Static constructor");
        }
        public SC()
        {
            firstname = "Ezra , Krisanta";
            lastname = "Garcia , Alejo";
    }

    }
}
