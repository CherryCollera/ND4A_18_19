﻿using System;


namespace StaticConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            SC a = new SC();
            SC a1 = new SC();
            Console.WriteLine(a1.firstname + " " + a1.lastname);
            Console.ReadLine();


        }
    }
}
