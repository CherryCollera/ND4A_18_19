﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StaticConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
