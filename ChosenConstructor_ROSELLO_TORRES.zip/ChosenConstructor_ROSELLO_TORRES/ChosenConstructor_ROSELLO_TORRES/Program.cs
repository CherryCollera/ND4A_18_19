﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace USINGCONSTRUCTOR_ROSELLO_TORRES
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
