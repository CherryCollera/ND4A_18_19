﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConstructorOverloading
{
    class sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "ROSELLO";
            lastname = "TORRES";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
    }
}
