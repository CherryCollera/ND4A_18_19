﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StaticConstructor
{
    class Sample
    {
        public string firstname, lastname;
        static Sample()
        {
            System.Console.WriteLine("Static constructor");
        }
        public Sample()
        {
            firstname = "Mayan";
            lastname = "Biscocho";

        }
    }
}
