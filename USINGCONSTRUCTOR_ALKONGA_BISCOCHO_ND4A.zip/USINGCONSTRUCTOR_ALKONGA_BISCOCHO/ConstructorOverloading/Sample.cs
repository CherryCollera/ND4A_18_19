﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConstructorOverloading
{
    class Sample
    {
        public string firstname, lastname;
        public Sample()
        {
            firstname = "Alkonga";
            lastname = "Biscocho";
        }
        public Sample(string x, string y)
        {
            firstname = x;
            lastname = y;
        }
    }
}
